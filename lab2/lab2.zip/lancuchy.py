# -*-coding: utf-8-*-

lancuch1 = '''Nam strzelać nie kazano. — Wstąpiłem na działo
I spojrzałem na pole
dwieście armat grzmiało.
Artyleryji ruskiéj ciągną się szeregi,
Prosto, długo, daleko, jako morza brzegi
I widziałem ich wodza
— przybiegł, mieczem skinął
I jak ptak jedno skrzydło wojska swego zwinął.
Wylewa się spod skrzydła ściśniona piechota
Długą, czarną kolumną, jako lawa błota,
Nasypana iskrami bagnetów. Jak sępy,
Czarne chorągwie na śmierć prowadzą zastępy'''

lancuch2 = '''Przeciw nim sterczy biała, wąska, zaostrzona,
Jak głaz, bodzący morze, reduta Ordona.
Sześć tylko miała harmat. Wciąż dymią i świecą;
I nie tyle prędkich słów gniewne usta miecą,
Nie tyle przejdzie uczuć przez duszę w rozpaczy,
Ile z tych dział leciało bomb, kul i kartaczy'''

print((lancuch1 + lancuch2 + '\n\n')*3)

lancuch = '''The quick brown fox jumps over the lazy dog'''
print(lancuch[0])
print(lancuch[:2])
print(lancuch[2:])
print(lancuch[-2])
print(lancuch[-3:])
print(lancuch[1::2])
